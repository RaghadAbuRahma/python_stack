from django.apps import AppConfig


class MovieActorAppConfig(AppConfig):
    name = 'movie_actor_app'
